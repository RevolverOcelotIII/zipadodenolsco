
namespace SGEP.Models
{
    public enum CargoUsuario
    {
        Almoxarife,
        Gerente
    }
}
