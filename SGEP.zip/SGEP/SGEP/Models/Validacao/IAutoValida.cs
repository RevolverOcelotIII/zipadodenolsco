﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SGEP.Models.Validacao
{
    interface IAutoValida
    {
        bool Validar();
    }
}
